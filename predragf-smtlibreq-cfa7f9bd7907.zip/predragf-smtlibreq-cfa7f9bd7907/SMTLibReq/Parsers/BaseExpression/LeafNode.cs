﻿namespace SMTLibReq.Parsers.BaseExpression
{
    public class LeafNode : Node
    {
        public LeafNode() : base() {
        }

        public LeafNode(string expression) : base(expression) {
        }
    }
}
