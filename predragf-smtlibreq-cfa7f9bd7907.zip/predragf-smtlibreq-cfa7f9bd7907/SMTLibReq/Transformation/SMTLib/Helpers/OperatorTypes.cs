﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMTLibReq.Transformation.SMTLib.Helpers
{
    public class OperatorTypes
    {
        public static string BINARY = "binary";
        public static string UNARY = "unary";
        public static string PATH = "path";
    }
}
