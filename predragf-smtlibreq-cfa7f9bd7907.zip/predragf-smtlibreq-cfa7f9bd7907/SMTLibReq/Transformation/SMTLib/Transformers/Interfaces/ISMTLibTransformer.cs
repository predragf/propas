﻿using SMTLibReq.Transformation.BaseTransformationStructures.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace SMTLibReq.Transformation.SMTLib.Transformers.Interfaces
{
    public interface ISMTLibTransformer : ISystemTransformer
    {

    }
}
