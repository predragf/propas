﻿
namespace SMTLibReq.ConsistencyAnalyzer
{
    public class Analyzer
    {
    }
}
